"""레시피 재료비 앱 (wxPython).

사용법: python app.py <recipes.json> [--selftest]
wxPython이 없으면 자동으로 pip 설치를 시도한다.
"""
import json
import subprocess
import sys

try:
    import wx
    import wx.grid as gridlib
except ImportError:
    print("wxPython이 없어 설치합니다: pip install wxPython")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "wxPython"])
    import wx
    import wx.grid as gridlib

COLS = ["재료", "수량", "단위", "단가(원)", "금액(원)"]


def fmt(n):
    return f"{round(n):,}"


def total(recipe):
    return sum(i["qty"] * i["unit_price"] for i in recipe["ingredients"])


class Frame(wx.Frame):
    def __init__(self, data):
        super().__init__(None, title=f"레시피 재료비 - {data.get('title', '')}", size=(900, 520))
        self.data = data
        self.recipes = data["recipes"]
        self.cur = 0

        panel = wx.Panel(self)
        root = wx.BoxSizer(wx.VERTICAL)
        body = wx.BoxSizer(wx.HORIZONTAL)

        self.lst = wx.ListCtrl(panel, style=wx.LC_REPORT | wx.LC_SINGLE_SEL, size=(300, -1))
        self.lst.InsertColumn(0, "레시피", width=170)
        self.lst.InsertColumn(1, "재료비 합계", width=110, format=wx.LIST_FORMAT_RIGHT)
        self.lst.Bind(wx.EVT_LIST_ITEM_SELECTED, self.on_select)

        right = wx.BoxSizer(wx.VERTICAL)
        self.name = wx.StaticText(panel, label="")
        self.name.SetFont(self.name.GetFont().Bold().Larger().Larger())
        self.grid = gridlib.Grid(panel)
        self.grid.CreateGrid(0, len(COLS))
        for c, h in enumerate(COLS):
            self.grid.SetColLabelValue(c, h)
        self.grid.SetColSize(0, 170)
        self.grid.SetRowLabelSize(30)
        self.grid.Bind(gridlib.EVT_GRID_CELL_CHANGED, self.on_edit)
        self.sum = wx.StaticText(panel, label="")
        self.sum.SetFont(self.sum.GetFont().Bold().Larger())
        right.Add(self.name, 0, wx.ALL, 8)
        right.Add(self.grid, 1, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        right.Add(self.sum, 0, wx.ALL | wx.ALIGN_RIGHT, 10)

        body.Add(self.lst, 0, wx.EXPAND | wx.ALL, 8)
        body.Add(right, 1, wx.EXPAND)
        note = wx.StaticText(panel, label="※ 가격은 추정가입니다. 수량·단가 칸을 직접 고치면 합계가 바뀝니다.")
        root.Add(body, 1, wx.EXPAND)
        root.Add(note, 0, wx.ALL, 8)
        panel.SetSizer(root)

        self.refresh_list()
        if self.recipes:
            self.lst.Select(0)
        self.Centre()

    def refresh_list(self):
        self.lst.DeleteAllItems()
        for i, r in enumerate(self.recipes):
            self.lst.InsertItem(i, r["name"])
            self.lst.SetItem(i, 1, fmt(total(r)) + "원")

    def on_select(self, evt):
        self.cur = evt.GetIndex()
        self.show()

    def show(self):
        r = self.recipes[self.cur]
        self.name.SetLabel(r["name"])
        g = self.grid
        if g.GetNumberRows():
            g.DeleteRows(0, g.GetNumberRows())
        g.AppendRows(len(r["ingredients"]))
        for row, ing in enumerate(r["ingredients"]):
            g.SetCellValue(row, 0, ing["name"])
            g.SetCellValue(row, 1, str(ing["qty"]))
            g.SetCellValue(row, 2, ing.get("unit", ""))
            g.SetCellValue(row, 3, str(ing["unit_price"]))
            g.SetReadOnly(row, 0)
            g.SetReadOnly(row, 2)
            g.SetReadOnly(row, 4)
            for c in (1, 3, 4):
                g.SetCellAlignment(row, c, wx.ALIGN_RIGHT, wx.ALIGN_CENTRE)
        self.recalc()

    def recalc(self):
        r = self.recipes[self.cur]
        for row, ing in enumerate(r["ingredients"]):
            self.grid.SetCellValue(row, 4, fmt(ing["qty"] * ing["unit_price"]))
        self.sum.SetLabel(f"총 재료비 합계: {fmt(total(r))}원")
        self.lst.SetItem(self.cur, 1, fmt(total(r)) + "원")
        self.Layout()

    def on_edit(self, evt):
        row, col = evt.GetRow(), evt.GetCol()
        ing = self.recipes[self.cur]["ingredients"][row]
        key = "qty" if col == 1 else "unit_price"
        try:
            ing[key] = float(self.grid.GetCellValue(row, col))
        except ValueError:
            pass
        self.grid.SetCellValue(row, col, f"{ing[key]:g}")
        self.recalc()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        sys.exit("사용법: python app.py <recipes.json>")
    with open(args[0], encoding="utf-8") as f:
        data = json.load(f)
    if "--selftest" in sys.argv:
        for r in data["recipes"]:
            print(r["name"], fmt(total(r)))
        return
    app = wx.App()
    Frame(data).Show()
    app.MainLoop()


if __name__ == "__main__":
    main()
